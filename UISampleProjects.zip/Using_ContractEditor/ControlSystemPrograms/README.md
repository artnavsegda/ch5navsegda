# CH5 Sample Control System Projects

SIMPL and SIMPL# sample programs

## In .\ControlSystemPrograms directory you will find 2 projects: SIMPL and S#



