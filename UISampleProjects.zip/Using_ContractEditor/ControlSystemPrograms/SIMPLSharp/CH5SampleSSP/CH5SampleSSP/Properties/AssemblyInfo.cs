﻿using System.Reflection;

[assembly: AssemblyTitle("CH5SampleSSP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CH5SampleSSP")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

