# CH5 Sample Contract Editor Contract

Sample Contract Editor contract to define the interface between UI projects and Control System projects 

# See Crestron Labs for documentation

http://www.crestronlabs.com/forumdisplay.php?229-Crestron-HTML5-Lab

# Ensure Contract Editor project files are in proper location relative to the sample SIMPL Program

For this sample, The "ContractEditor" folder should be located at the same level as the "ControlSystemsPrograms" folder
     .\ContractEditor
     .\ControlSystemPrograms
     .\UISampleProjects

# Open contract and review the components

Install and launch Contract Editor

Navigate to and open .\ContrlEditor\Ch5SampleContract\ch5SampleContract.cce

Build the contract via the build icon on the toolbar




