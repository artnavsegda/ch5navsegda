module.exports = function (val) {
    if(val !== ""){
        return true;
    } else {
        return false;
    }
};